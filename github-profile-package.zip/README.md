::: {align="center"}
# Talha Semih Pertev

### Software Engineer · Mobile & Backend Developer

I build mobile applications, web platforms, and practical software
solutions.

```{=html}
<p>
```
`<a href="https://github.com/TPertev">`{=html}`<img src="https://img.shields.io/badge/GitHub-TPertev-181717?style=for-the-badge&logo=github" alt="GitHub" />`{=html}`</a>`{=html}
`<a href="https://www.ruyai.app/en">`{=html}`<img src="https://img.shields.io/badge/RuyAI-Explore%20the%20app-6D42E8?style=for-the-badge" alt="RuyAI" />`{=html}`</a>`{=html}
`<a href="https://www.aydinhoca.com">`{=html}`<img src="https://img.shields.io/badge/Website-Aydın%20Hoca-2563EB?style=for-the-badge" alt="Aydın Hoca" />`{=html}`</a>`{=html}
```{=html}
</p>
```
:::

------------------------------------------------------------------------

## About Me

I'm a Software Engineering student and developer interested in building
useful, reliable, and maintainable digital products.

-   Mobile application development
-   Backend systems, APIs, and database-driven applications
-   Full-stack web development
-   Hardware and software integration
-   Continuous learning through hands-on projects

------------------------------------------------------------------------

## Featured Projects

I use this section to showcase products I've built and websites I've
developed. Some projects are presented as live products because their
source code is private or not publicly available.

### Mobile Applications

```{=html}
<table>
```
```{=html}
<tr>
```
```{=html}
<td width="38%" valign="top">
```
`<img src="./assets/projects/ruyai/ruyai-screenshots.png" alt="RuyAI app promotional screenshots" width="100%" />`{=html}
```{=html}
</td>
```
```{=html}
<td valign="top">
```
```{=html}
<h3>
```
RüyAI --- AI Dream Journal & Analysis
```{=html}
</h3>
```
```{=html}
<p>
```
An iPhone application that helps users record, explore, and visualize
their dreams with AI-powered analysis.
```{=html}
</p>
```
```{=html}
<ul>
```
```{=html}
<li>
```
Record dreams by writing or speaking
```{=html}
</li>
```
```{=html}
<li>
```
Explore symbols, emotions, and recurring patterns
```{=html}
</li>
```
```{=html}
<li>
```
Choose from five interpretation perspectives
```{=html}
</li>
```
```{=html}
<li>
```
Generate AI visuals and turn dream stories into short videos
```{=html}
</li>
```
```{=html}
<li>
```
Keep dream entries in a personal journal
```{=html}
</li>
```
```{=html}
</ul>
```
```{=html}
<p>
```
`<strong>`{=html}Platform:`</strong>`{=html} iOS
```{=html}
</p>
```
```{=html}
<p>
```
`<strong>`{=html}App listing:`</strong>`{=html}
`<a href="https://www.ruyai.app/en">`{=html}RuyAI website`</a>`{=html}
```{=html}
</p>
```
```{=html}
<p>
```
`<strong>`{=html}Developer:`</strong>`{=html} Talha Semih Pertev
```{=html}
</p>
```
```{=html}
</td>
```
```{=html}
</tr>
```
```{=html}
</table>
```
```{=html}
<p align="center">
```
`<img src="./assets/projects/ruyai/ruyai-app-store.png" alt="RuyAI App Store listing" width="100%" />`{=html}
```{=html}
</p>
```
### Web Development

  ----------------------------------------------------------------------------------------------------
  Project                 What it is              Live website
  ----------------------- ----------------------- ----------------------------------------------------
  Aydın Hoca              Education-focused       [aydinhoca.com](https://www.aydinhoca.com)
                          website and digital     
                          platform                

  Hairspace Clinic        Clinic website          [hairspaceclinic.com](https://hairspaceclinic.com)

  İbrisim Butik           Boutique / e-commerce   [ibrisimbutik.com](https://www.ibrisimbutik.com)
                          website                 

  Nuq Atelier             Brand website           [nuqatelier.com](https://www.nuqatelier.com)

  Vwork                   Business website        [vwork.com.tr](https://vwork.com.tr)
  ----------------------------------------------------------------------------------------------------

> Project descriptions and technology tags can be expanded as each
> project's details are confirmed. Client-owned source code is not
> published here unless authorized.

------------------------------------------------------------------------

## Technologies & Tools

```{=html}
<p>
```
`<img src="https://skillicons.dev/icons?i=java,dart,flutter,js,ts,python,html,css,react,nextjs,nodejs,mysql,postgres,sqlite,docker,git,github,vscode,idea,postman" alt="Technologies and tools" />`{=html}
```{=html}
</p>
```

------------------------------------------------------------------------

## GitHub Activity

::: {align="center"}
`<img height="165" src="https://github-readme-stats.vercel.app/api?username=TPertev&show_icons=true&theme=tokyonight&hide_border=true&include_all_commits=true" alt="GitHub statistics" />`{=html}
`<img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=TPertev&layout=compact&theme=tokyonight&hide_border=true" alt="Most used languages" />`{=html}
`<br />`{=html}
`<img src="https://streak-stats.demolab.com?user=TPertev&theme=tokyonight&hide_border=true" alt="GitHub contribution streak" />`{=html}
`<br />`{=html}
`<img src="https://github-readme-activity-graph.vercel.app/graph?username=TPertev&theme=tokyo-night&hide_border=true" alt="GitHub activity graph" />`{=html}
:::

------------------------------------------------------------------------

## Connect

-   GitHub: [@TPertev](https://github.com/TPertev)
-   RuyAI: [ruyai.app](https://www.ruyai.app/en)
-   Aydın Hoca: [aydinhoca.com](https://www.aydinhoca.com)

::: {align="center"}
`<sub>`{=html}Thanks for visiting. Feel free to explore my work and
connect!`</sub>`{=html}
:::
